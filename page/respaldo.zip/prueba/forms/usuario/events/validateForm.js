function validateForm(form){
	
	if(form.getValue("nombre") == ""){
		
		throw "Campo vacio";
		console.log("Campo Nombre esta Vacio");
		
	} else if(form.getValue("apellido") == ""){
		
		throw "Campo Apellido vacio";
		console.log("Campo Apellido esta Vacio");
	} else if(form.getValue("edad") == ""){
		
		throw "Campo Apellido edad";
		console.log("Campo edad esta Vacio");
	}
	
}